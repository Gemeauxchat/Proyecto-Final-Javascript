localStorage.setItem("key", "content")
console.log(localStorage.getItem("key"))



